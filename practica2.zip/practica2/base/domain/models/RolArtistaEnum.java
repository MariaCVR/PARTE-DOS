package com.unl.practica.base.domain.models;

public enum RolArtistaEnum {
    SOLISTA, VOCALISTA, BATERISTA, BAJISTA, GUITARRSITA;
    
}

