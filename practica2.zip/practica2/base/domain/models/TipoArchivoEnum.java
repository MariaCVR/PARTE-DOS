package com.unl.practica.base.domain.models;

public enum TipoArchivoEnum {
    FISICO,
    VIRTUAL;
}
